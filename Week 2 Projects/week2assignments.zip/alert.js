// Is the JavaScript file sourced? Check in the browser console by
// right clicking and selecting 'Inspect'. If the script is properly
// sourced you will see the log message: 'Script sourced!'.
//console.log('Script sourced!');

var animal;

if(animal == "turtle") {
            alert("How did you know?!");
    }
    else {
        alert("Try Again");
    }; 

// * Step One * - Create a variable from user input and conditional statement
  // var animal =
// Once you have the animal variable. Write your conditional statement.
// Use these exact strings: 'Try again.' and 'How did you know?!'.


var animalName = prompt("Of what animal am I thinking?");

function animalGuess(animal) {
    
    if(animal == "turtle") {
            alert("How did you know?!");
    }
    else {
        alert("Try Again");
    }
};
    
    

// * Step Two * - Refactor into a function
// Call the function by passing the animal variable into it






// What will this log?
// console.log(animalName);
when you console.log(animalName) you get a value of turtle